import os
from flask import Flask, render_template, request, redirect, url_for, flash, session,send_from_directory
from flask_mysqldb import MySQL

app = Flask(__name__)

app.secret_key = 'malbourne team'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'emarket'

mysql = MySQL(app)

@app.route("/")
def home():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM product")
    data = cur.fetchall()
    cur.close()
    return render_template('index.html', products=data)

@app.route("/adminpassword")
def adminpassword():
    return render_template('admin-password.html')

@app.route("/executepayment", methods=['GET', 'POST'])
def executepayment():
    username=session['cusername']
    cid=session['cid']
    paymentid = request.args['paymentId']
    token = request.args['token']
    payerid = request.args['PayerID']
    cursor = mysql.connection.cursor()
    cursor.execute("INSERT INTO payment_detail (cid,name, paymentid,token, payerid) VALUES (%s, %s,%s, %s, %s)", (cid,username, paymentid, token, payerid))
    mysql.connection.commit()


    return render_template('executepayment.html')

@app.route("/clientpassword")
def clientpassword():
    return render_template('client-password.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    loginpage=''

    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM client WHERE name = %s AND password = %s', (username, password))
        client = cursor.fetchone()
        if client:
            session['cid'] = client[0]
            session['cusername'] = client[1]
            # Redirect to home page
            flash('Client Logged in successfully!')
            loginpage='client.html'
        else:
            loginpage = 'index.html'
            flash('Incorrect username/password!')

    else:
        if "cusername" in session:
            loginpage = 'client.html'

    return render_template(loginpage)

@app.route('/logincart', methods=['GET', 'POST'])
def logincart():
    loginpage=''



    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM client WHERE name = %s AND password = %s', (username, password))
        client = cursor.fetchone()

        if client:
            session['cid'] = client[0]
            session['cusername'] = client[1]


            # Redirect to home page
            flash('Client Logged in successfully!')
            loginpage='client-checkout.html'
        else:
            loginpage = 'checkout.html'
            flash('Incorrect username/password!')
    else:
        if "cusername" in session:
            loginpage = 'client-checkout.html'
    return render_template(loginpage)

@app.route('/signup', methods=['GET', 'POST'])
def signup():

    if request.method == 'POST' and 'name' in request.form and 'password' in request.form:
        username = request.form['name']
        email = request.form['email']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO client (name, email, password) VALUES (%s, %s, %s)", (username, email, password))
        mysql.connection.commit()
        flash('Client account created successfully!')
        return render_template("index.html")

@app.route('/adminlogin', methods=['GET', 'POST'])
def adminlogin():
    loginpage=''

    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM admin WHERE username = %s AND password = %s', (username, password))
        admin = cursor.fetchone()
        if admin:
            session['id'] = admin[0]
            session['username'] = admin[1]
            # Redirect to home page
            flash('Admin Logged in successfully!')
            loginpage='adminpanel.html'
        else:
            loginpage = 'admin.html'
            flash('Incorrect username/password!')
    else:
        if "username" in session:
            loginpage = 'adminpanel.html'


    return render_template(loginpage)

@app.route('/viewclient')
def viewclient():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM client")
    data = cur.fetchall()
    cur.close()
    return render_template('view-client.html', clients=data )

@app.route('/vieworder')
def vieworder():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM order_product")
    data = cur.fetchall()
    cur.close()
    return render_template('view-order.html', clients=data )

@app.route('/viewclientorder')
def viewclientorder():
    cid=session['cid']
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM order_product where cid=%s",(cid,))
    data = cur.fetchall()
    cur.close()
    return render_template('view-client-order.html', clients=data )

@app.route('/viewpayment')
def viewpayment():

    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM payment_detail")
    data = cur.fetchall()
    cur.close()
    return render_template('view-payment.html', clients=data )

@app.route('/viewclientpayment')
def viewclientpayment():
    cid = session['cid']
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM payment_detail where cid=%s",(cid,))
    data = cur.fetchall()
    cur.close()
    return render_template('view-client-payment.html', clients=data )

@app.route('/updateclient')
def updateclient():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM client")
    data = cur.fetchall()
    cur.close()
    return render_template('update-client.html', clients=data )

@app.route('/updatesingleclient')
def updatesingleclient():

    cur = mysql.connection.cursor()
    cid = session["cid"]
    cur.execute("SELECT  * FROM client where id=%s",(cid,))
    data = cur.fetchall()
    cur.close()
    return render_template('update-single-client.html', clients=data )

@app.route('/manageproducts')
def manageproducts():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM product")
    data = cur.fetchall()
    cur.close()
    return render_template('manageproducts.html', products=data )

@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/product")
def product():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM product")
    data = cur.fetchall()
    cur.close()
    return render_template('product.html',products=data)

@app.route("/single")
def single():
    return render_template('single.html')

@app.route("/checkout", methods=['GET', 'POST'])
def checkout():
    cid = session['cid']

    username=session['cusername']
    for i in range(1, 3):
        item = request.form['item_name_' + str(i)]
        quantity = request.form['quantity_' + str(i)]
        amount = request.form['amount_' + str(i)]
        print(item)
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO order_product (cid, name, item, quantity, amount) VALUES (%s, %s,%s, %s, %s)",
                       (cid, username, item, quantity, amount))

    mysql.connection.commit()
    return render_template('checkout.html')

@app.route("/payment", methods=['GET', 'POST'])
def payment():
    return render_template('payment.html')

@app.route('/updatecdata',methods=['POST','GET'])
def updatecdata():
    if request.method == 'POST':
        id_data = request.form['id']
        name = request.form['name']
        address = request.form['address']
        email = request.form['email']
        password = request.form['passw']
        phone = request.form['phone']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE client
               SET name=%s,address=%s, email=%s,password=%s,contact=%s
               WHERE id=%s
            """, (name, address, email,password, phone, id_data))
        flash("Client Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('updateclient'))

@app.route('/updatesinglecdata',methods=['POST','GET'])
def updatesinglecdata():
    if request.method == 'POST':
        id_data = request.form['id']
        name = request.form['name']
        address = request.form['address']
        email = request.form['email']
        password = request.form['passw']
        phone = request.form['phone']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE client
               SET name=%s,address=%s, email=%s,password=%s,contact=%s
               WHERE id=%s
            """, (name, address, email,password, phone, id_data))
        flash("Client Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('updatesingleclient'))

@app.route('/clientpchange', methods=['POST', 'GET'])
def clientpchange():
    urlpchange=''
    if request.method == 'POST':
        opassword = request.form['opassword']
        npassword = request.form['npassword']
        cid=session["cid"]
        cur = mysql.connection.cursor()
        cur.execute("SELECT  * FROM client where id=%s and password=%s",(cid,opassword))
        data = cur.fetchone()
        if data:
            cur.execute("""
            UPDATE client
            SET password=%s
            WHERE id=%s
            """, (npassword, cid))
            flash("Client Password Updated Successfully")
            mysql.connection.commit()
            urlpchange='client.html'
        else:
            flash("Old Password not matched")
            urlpchange='client-password.html'
    return render_template(urlpchange)

@app.route('/adminpchange', methods=['POST', 'GET'])
def adminpchange():
    urlpchange=''
    if request.method == 'POST':
        opassword = request.form['opassword']
        npassword = request.form['npassword']
        uname='kalyani'
        cur = mysql.connection.cursor()
        cur.execute("SELECT  * FROM admin where username=%s and password=%s",(uname,opassword))
        data = cur.fetchone()
        if data:
            cur.execute("""
            UPDATE admin
            SET password=%s
            WHERE username=%s
            """, (npassword, uname))
            flash("Admin Password Updated Successfully")
            mysql.connection.commit()
            urlpchange='adminpanel.html'
        else:
            flash("Old Password not matched")
            urlpchange='admin-password.html'
    return render_template(urlpchange)

@app.route('/deletecdata/<string:id_data>', methods = ['GET'])
def deletecdata(id_data):
    flash("Client data has been deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM client WHERE id=%s", (id_data))
    mysql.connection.commit()
    return redirect(url_for('updateclient'))

@app.route('/deletepdata/<string:id_data>', methods = ['GET'])
def deletepdata(id_data):
    flash("Product detail has been deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM product WHERE pid=%s", (id_data))
    mysql.connection.commit()
    return redirect(url_for('manageproducts'))

@app.route("/contact")
def contact():
    return render_template('contact.html')

@app.route("/admin")
def admin():
    return render_template('admin.html')

@app.route("/addproducts")
def addproducts():
    return render_template('addproducts.html')

@app.route("/upload", methods=["POST"])
def upload():

    APP_ROOT = os.path.dirname(os.path.abspath(__file__))

    target = os.path.join(APP_ROOT, 'static/products/')

    if not os.path.isdir(target):
        os.mkdir(target)
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):

        print("{} is the file name".format(upload.filename))
        filename = upload.filename
        #verify files are supported
        ext = os.path.splitext(filename)[1]
        if (ext == ".jpg") or (ext == ".png"):
            print("File supported.")
        else:
            flash("File extension not supported")
            render_template("adminpanel.html")
        destination = "/".join([target, filename])
        print(destination)
        upload.save(destination)
    if request.method == 'POST' and 'pname' in request.form and 'pdesc' in request.form:
        pname = request.form['pname']
        pdesc = request.form['pdesc']
        quantity = request.form['quantity']
        available = request.form['available']
        aprice = request.form['aprice']
        dprice = request.form['dprice']
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO product (pname, pdesc, quantity, available, aprice, dprice,path) VALUES (%s, %s, %s,%s, %s, %s,%s)", (pname, pdesc, quantity, available, aprice, dprice,filename))
        mysql.connection.commit()
        flash('Product detail added successfully!')

    return render_template("adminpanel.html")
@app.route('/updatepdata',methods=['POST','GET'])
def updatepdata():
    if request.method == 'POST':
        id_data = request.form['id']
        pname = request.form['pname']
        pdesc = request.form['pdesc']
        quantity = request.form['quantity']
        available = request.form['available']
        aprice = request.form['aprice']
        dprice = request.form['dprice']
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE product
               SET pname=%s,pdesc=%s, quantity=%s,available=%s,aprice=%s, dprice=%s
               WHERE pid=%s
            """, (pname, pdesc, quantity, available, aprice, dprice, id_data))
        flash("Product Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('manageproducts'))


if __name__ == "__main__":
    app.run(debug=True)