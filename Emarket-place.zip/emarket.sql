-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 09, 2020 at 08:09 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `emarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'kalyani', 'sukhraj');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `contact` varchar(500) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `name`, `address`, `email`, `password`, `contact`) VALUES
(1, 'sarb', 'australia', 'sarb@gmail.com', '1234', '9956168'),
(3, 'aman', 'datafdaod', 'priyankadhingra43@gmail.com', '123', '88966655');

-- --------------------------------------------------------

--
-- Table structure for table `order_product`
--

CREATE TABLE `order_product` (
  `id` int(100) NOT NULL auto_increment,
  `cid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `item` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `amount` int(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `order_product`
--

INSERT INTO `order_product` (`id`, `cid`, `name`, `item`, `quantity`, `amount`) VALUES
(1, 1, 'sarb', 'Surf Excel Liquid, 1.02L', 2, 178),
(2, 1, 'sarb', 'Surf Excel Liquid, 1.02L', 2, 178),
(3, 1, 'sarb', 'Surf Excel Liquid, 1.02L', 2, 178),
(4, 1, 'sarb', 'Surf Excel Liquid, 1.02L', 2, 178),
(5, 1, 'sarb', 'Kissan Tomato Ketchup, 950g', 2, 80);

-- --------------------------------------------------------

--
-- Table structure for table `payment_detail`
--

CREATE TABLE `payment_detail` (
  `id` int(100) NOT NULL auto_increment,
  `cid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `paymentid` varchar(100) NOT NULL,
  `token` varchar(100) NOT NULL,
  `payerid` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `payment_detail`
--

INSERT INTO `payment_detail` (`id`, `cid`, `name`, `paymentid`, `token`, `payerid`) VALUES
(1, 1, 'sarb', 'PAYID-L3P5B7I8BA15546H20290339', 'EC-0T693895X5072181N', 'Q7R7HEB67H94Y');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL auto_increment,
  `pname` varchar(50) NOT NULL,
  `pdesc` varchar(200) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `available` varchar(50) NOT NULL,
  `aprice` varchar(50) NOT NULL,
  `dprice` varchar(50) NOT NULL,
  `path` varchar(100) NOT NULL,
  UNIQUE KEY `pid` (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `pdesc`, `quantity`, `available`, `aprice`, `dprice`, `path`) VALUES
(2, 'Kissan Tomato Ketchup, 950g', 'tasty ketchup', '5', 'Free Shipping', '99', '80', 's4.jpg'),
(3, 'Madhur Pure Sugar, 1g', 'Pure Sugar', '10', 'Free Shipping', '78', '68', 's2.jpg'),
(4, 'Surf Excel Liquid, 1.02L', 'Excel in Liquid', '12', 'Free Shipping', '187', '178', 's3.jpg'),
(5, 'Sprite, 2.25L', 'Sprite, 2.25L (Pack of 2)', '10', 'Free Shipping', '180', '158', 's5.jpg');
